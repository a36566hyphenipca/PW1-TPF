const ROOMS = [
  {id: 1, name: '101', rate: 60, desc: 'Casal Standard'},
  {id: 2, name: '102', rate: 80, desc: 'Duplo Superior'},
  {id: 3, name: '201', rate: 120, desc: 'Suite'},
  {id: 4, name: '202', rate: 75, desc: 'Familiar'},
  {id: 5, name: '203', rate: 90, desc: 'Duplo Deluxe'},
  {id: 6, name: '301', rate: 140, desc: 'Suite Luxo'},
  {id: 7, name: '302', rate: 65, desc: 'Single'},
  {id: 8, name: '303', rate: 110, desc: 'Family Suite'},
  {id: 9, name: '401', rate: 160, desc: 'Presidential'},
  {id: 10, name: '402', rate: 95, desc: 'Junior Suite'},
];

let reservations = [
  {id: 1, guest: 'Ana', roomId:1, start:'2025-03-10', end:'2025-03-13'},
  {id: 2, guest: 'Miguel', roomId:2, start:'2025-03-12', end:'2025-03-15'},
  {id: 3, guest: 'Sara', roomId:3, start:'2025-07-01', end:'2025-07-05'},
];

const MONTHS = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];

// Multiplicadores por mês (ex: Dezembro alta procura — Natal/AnoNovo)
const MONTH_MULTIPLIERS = [1.00, 0.95, 0.95, 1.00, 1.05, 1.10, 1.20, 1.25, 1.00, 1.00, 1.05, 1.50];

function $(id){return document.getElementById(id)}

function init(){
  // navigation
  $('btnDashboard').onclick = ()=>showView('dashboard');
  $('btnRooms').onclick = ()=>showView('rooms');
  $('btnRes').onclick = ()=>showView('reservations');

  // month select
  const ms = $('monthSelect');
  MONTHS.forEach((m,i)=>{ let opt=document.createElement('option'); opt.value=i; opt.text=m; ms.add(opt); });
  ms.value = 0; ms.onchange = ()=>{ renderCalendar(+ms.value); renderAnalytics(+ms.value); };

  // reservation form
  $('resForm').onsubmit = (e)=>{ e.preventDefault(); createReservation(); };

  renderRooms();
  populateRoomSelect();
  renderReservations();
  renderCalendar(0);
  renderAnalytics(0);
  renderPriceTable();
}

function showView(id){ document.querySelectorAll('.view').forEach(v=>v.classList.add('d-none')); $(id).classList.remove('d-none');
  document.querySelectorAll('.list-group-item').forEach(b=>b.classList.remove('active'));
  if(id==='dashboard') $('btnDashboard').classList.add('active');
  if(id==='rooms') $('btnRooms').classList.add('active');
  if(id==='reservations') $('btnRes').classList.add('active');
}

function renderRooms(){
  const tbody = document.querySelector('#roomsTable tbody'); tbody.innerHTML='';
  ROOMS.forEach(r=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.id}</td><td>${r.name}</td><td>€${r.rate.toFixed(2)}</td><td>${r.desc}</td>`;
    tbody.appendChild(tr);
  });
}

function populateRoomSelect(){
  const sel = $('roomSelect'); sel.innerHTML='';
  ROOMS.forEach(r=>{ const o = document.createElement('option'); o.value=r.id; o.text=`${r.name} — €${r.rate}`; sel.add(o); });
}

function renderReservations(){
  const tbody = document.querySelector('#resTable tbody'); tbody.innerHTML='';
  reservations.forEach(r=>{
    const room = ROOMS.find(x=>x.id===r.roomId);
    const nights = dateDiff(r.start,r.end);
    const total = nights * room.rate;
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.id}</td><td>${r.guest}</td><td>${room.name}</td><td>${r.start}</td><td>${r.end}</td><td>${nights}</td><td>€${total.toFixed(2)}</td><td><button class="btn btn-sm btn-danger" onclick="cancelReservation(${r.id})">Anular</button></td>`;
    tbody.appendChild(tr);
  });
}

function createReservation(){
  const guest = $('guestName').value.trim();
  const roomId = +$('roomSelect').value;
  const start = $('startDate').value;
  const end = $('endDate').value;
  if(!guest || !start || !end) return alert('Preencha todos os campos');
  if(!in2025(start) || !in2025(end)) return alert('As datas devem pertencer a 2025');
  if(new Date(start) >= new Date(end)) return alert('Data de saída deve ser posterior à entrada');

  // check overlap
  const conflict = reservations.some(r=> r.roomId===roomId && rangesOverlap(r.start,r.end,start,end) );
  if(conflict) return alert('Conflito com reserva existente para este quarto');

  const id = reservations.length? Math.max(...reservations.map(x=>x.id))+1 : 1;
  reservations.push({id, guest, roomId, start, end});
  renderReservations(); renderCalendar(+$('monthSelect').value); renderAnalytics(+$('monthSelect').value);
  $('resForm').reset();
}

function cancelReservation(id){ if(!confirm('Anular reserva?')) return; reservations = reservations.filter(r=>r.id!==id); renderReservations(); renderCalendar(+$('monthSelect').value); renderAnalytics(+$('monthSelect').value); }

function renderCalendar(monthIndex){
  const cal = $('calendar'); cal.innerHTML='';
  const year = 2025;
  const days = new Date(year, monthIndex+1, 0).getDate();

  for(let d=1; d<=days; d++){
    const dayEl = document.createElement('div'); dayEl.className='day';
    const dateStr = toDateStr(year,monthIndex+1,d);
    const matches = reservationsForDate(dateStr);
    if(matches.length===0) dayEl.textContent = d;
    else if(matches.length===1){ dayEl.classList.add('reserved'); dayEl.textContent=d; dayEl.title = matches.map(r=>`${r.guest} (${roomName(r.roomId)})`).join('\n'); }
    else { dayEl.classList.add('multires'); dayEl.textContent=d; dayEl.title = matches.map(r=>`${r.guest} (${roomName(r.roomId)})`).join('\n'); }
    cal.appendChild(dayEl);
  }
}

function reservationsForDate(dateStr){ return reservations.filter(r=> dateInRange(dateStr, r.start, r.end)); }

function dateInRange(dateStr, start, end){ const d=new Date(dateStr); return d>=new Date(start) && d<new Date(end); }

function rangesOverlap(aStart,aEnd,bStart,bEnd){ return new Date(aStart) < new Date(bEnd) && new Date(bStart) < new Date(aEnd); }

function dateDiff(a,b){ const as=new Date(a); const bs=new Date(b); const diff = (bs-as)/(1000*60*60*24); return Math.max(0,Math.round(diff)); }

function toDateStr(y,m,d){ return `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`; }

function roomName(id){ const r=ROOMS.find(x=>x.id===id); return r? r.name : '' }

function in2025(dateStr){ return dateStr.startsWith('2025-'); }

function renderAnalytics(monthIndex){
  // days reserved in month and revenue month
  const year = 2025; const m = monthIndex; const daysInMonth = new Date(year,m+1,0).getDate();
  let daysReserved = 0; let revenue = 0;

  for(const r of reservations){
    // for each reservation compute overlap with the month
    const start = new Date(r.start); const end = new Date(r.end);
    const monthStart = new Date(year,m,1); const monthEnd = new Date(year,m,daysInMonth+1);
    const startOverlap = start < monthStart ? monthStart : start;
    const endOverlap = end > monthEnd ? monthEnd : end;
    if(startOverlap < endOverlap){
      const overlapDays = Math.round((endOverlap - startOverlap)/(1000*60*60*24));
      daysReserved += overlapDays;
      const room = ROOMS.find(x=>x.id===r.roomId);
      revenue += overlapDays * room.rate;
    }
  }

  $('daysReserved').textContent = daysReserved;
  $('revenueMonth').textContent = `€${revenue.toFixed(2)}`;

  // annual revenue per month
  const ul = $('revenueYear'); ul.innerHTML='';
  for(let mm=0; mm<12; mm++){
    let rev=0;
    for(const r of reservations){
      const start = new Date(r.start); const end = new Date(r.end);
      const monthStart = new Date(2025,mm,1); const monthEnd = new Date(2025,mm,new Date(2025,mm+1,0).getDate()+1);
      const startOverlap = start < monthStart ? monthStart : start;
      const endOverlap = end > monthEnd ? monthEnd : end;
      if(startOverlap < endOverlap){ const overlapDays = Math.round((endOverlap - startOverlap)/(1000*60*60*24)); rev += overlapDays * ROOMS.find(x=>x.id===r.roomId).rate; }
    }
    const li = document.createElement('li'); li.className='list-group-item d-flex justify-content-between align-items-center'; li.textContent = `${MONTHS[mm]}`; const span=document.createElement('span'); span.textContent = `€${rev.toFixed(2)}`; li.appendChild(span); ul.appendChild(li);
  }
}

function getPriceForRoom(room, monthIndex){
  const mult = MONTH_MULTIPLIERS[monthIndex] || 1.0;
  return +(room.rate * mult).toFixed(2);
}

function renderPriceTable(){
  const tbody = document.querySelector('#priceTable tbody'); tbody.innerHTML='';
  const refRoom = ROOMS.find(r=>r.id===1) || ROOMS[0];
  for(let m=0;m<12;m++){
    const mult = MONTH_MULTIPLIERS[m] || 1.0;
    const examplePrice = getPriceForRoom(refRoom,m);
    const tr = document.createElement('tr');
    const note = (m===11)? 'Alta procura: Natal / Ano Novo' : (mult>1.15? 'Alt estação' : '');
    tr.innerHTML = `<td>${MONTHS[m]}</td><td>x${mult.toFixed(2)}</td><td>€${examplePrice.toFixed(2)}</td><td>${note}</td>`;
    tbody.appendChild(tr);
  }
}

// init after DOM
document.addEventListener('DOMContentLoaded', init);
