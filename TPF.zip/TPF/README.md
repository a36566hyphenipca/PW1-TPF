# Gestão Hotel — Interface Frontend (2025)

Estrutura:
- indexhotel.html — página principal
- estilos/style.css — estilos personalizados
- js/app.js — lógica, arrays de dados (rooms, reservations)

Como usar:
1. Abrir `indexhotel.html` num browser.
2. Selecionar mês no painel à esquerda para ver o calendário e indicadores.
3. Em "Reservas" criar novas reservas para o ano 2025 (validação aplicada).

Notas técnicas:
- Os dados estão em arrays dentro de `js/app.js`; não há persistência.
- Todas as formatações estão em `estilos/style.css` e Bootstrap.
