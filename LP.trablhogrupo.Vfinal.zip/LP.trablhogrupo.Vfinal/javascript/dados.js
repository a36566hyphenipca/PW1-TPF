
let reservas = JSON.parse(localStorage.getItem("reservas")) || [];



const totalQuartos = {
  simples: 10,
  suite: 10,
  familiar: 10
};

